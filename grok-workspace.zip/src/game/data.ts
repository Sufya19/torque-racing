export type UpgradeKey = "engine" | "tires" | "suspension" | "fuel";

export type UpgradeLevels = Record<UpgradeKey, number>;

export type Skin = {
  name: string;
  price: number;
  body: string;
  accent: string;
  glass: string;
  rim: string;
  dark: string;
};

export type BodyKind = "jeep" | "monster" | "sport" | "bike" | "tractor" | "truck" | "super" | "heavy";

export type PropKind = "meadow" | "desert" | "snow" | "forest" | "volcano" | "moon";

export type VehicleDef = {
  id: string;
  name: string;
  blurb: string;
  price: number;
  mass: number;
  wheelbase: number;
  rRear: number;
  rFront: number;
  engine: number;
  brake: number;
  grip: number;
  maxSpeed: number;
  fuel: number;
  fuelRate: number;
  air: number;
  torqueScale: number;
  stiff: number;
  damp: number;
  raise: number;
  angDamp: number;
  headX: number;
  headY: number;
  body: BodyKind;
};

export type MapDef = {
  id: string;
  name: string;
  region: string;
  blurb: string;
  seed: number;
  seg: number;
  amp: number;
  wave: number;
  gravity: number;
  bridge: number;
  gripMul: number;
  unlockDist: number;
  price: number;
  skyTop: string;
  skyHorizon: string;
  duskTop: string;
  duskHorizon: string;
  nightTop: string;
  nightHorizon: string;
  mountain: string;
  mountainFar: string;
  grass: string;
  grassDark: string;
  soil: string;
  soilDeep: string;
  prop: PropKind;
  cloud: string;
};

export type Tuned = VehicleDef & {
  fuelCap: number;
  comAbove: number;
  inertia: number;
  rear: { lx: number; ly: number; r: number };
  front: { lx: number; ly: number; r: number };
};

export const MAX_UPGRADE = 5;

export const EMPTY_UPGRADES: UpgradeLevels = { engine: 0, tires: 0, suspension: 0, fuel: 0 };

export const VEHICLES: VehicleDef[] = [
  {
    id: "jeep",
    name: "Trail Jeep",
    blurb: "Balanced starter. Climbs clean and forgives a bad landing.",
    price: 0,
    mass: 1.15,
    wheelbase: 2.15,
    rRear: 0.48,
    rFront: 0.48,
    engine: 64,
    brake: 50,
    grip: 1.45,
    maxSpeed: 23,
    fuel: 110,
    fuelRate: 4.6,
    air: 1.15,
    torqueScale: 0.32,
    stiff: 340,
    damp: 40,
    raise: 0.52,
    angDamp: 2.4,
    headX: 0.12,
    headY: 0.62,
    body: "jeep",
  },
  {
    id: "bike",
    name: "Dirt Bike",
    blurb: "Featherweight. Wheelies easy and lives in the air.",
    price: 750,
    mass: 0.58,
    wheelbase: 1.48,
    rRear: 0.4,
    rFront: 0.4,
    engine: 38,
    brake: 30,
    grip: 1.25,
    maxSpeed: 26,
    fuel: 78,
    fuelRate: 4.1,
    air: 2.2,
    torqueScale: 0.12,
    stiff: 220,
    damp: 20,
    raise: 0.58,
    angDamp: 1.15,
    headX: 0.08,
    headY: 0.98,
    body: "bike",
  },
  {
    id: "tractor",
    name: "Farm Tractor",
    blurb: "Huge rear torque. Slow, sticky, and almost unflippable.",
    price: 1400,
    mass: 2.05,
    wheelbase: 2.05,
    rRear: 0.72,
    rFront: 0.36,
    engine: 88,
    brake: 60,
    grip: 2.1,
    maxSpeed: 15,
    fuel: 150,
    fuelRate: 5.2,
    air: 0.5,
    torqueScale: 0.18,
    stiff: 420,
    damp: 52,
    raise: 0.46,
    angDamp: 3.4,
    headX: -0.15,
    headY: 0.78,
    body: "tractor",
  },
  {
    id: "sport",
    name: "Sports Car",
    blurb: "Low and quick. Hates ruts, loves a smooth crest.",
    price: 2600,
    mass: 0.92,
    wheelbase: 2.35,
    rRear: 0.36,
    rFront: 0.36,
    engine: 78,
    brake: 62,
    grip: 1.25,
    maxSpeed: 32,
    fuel: 88,
    fuelRate: 5.4,
    air: 1.0,
    torqueScale: 0.16,
    stiff: 460,
    damp: 36,
    raise: 0.34,
    angDamp: 2.1,
    headX: 0.2,
    headY: 0.42,
    body: "sport",
  },
  {
    id: "monster",
    name: "Monster Truck",
    blurb: "Giant tires swallow landings. Heavy, loud, unstoppable.",
    price: 4200,
    mass: 2.4,
    wheelbase: 2.55,
    rRear: 0.78,
    rFront: 0.78,
    engine: 96,
    brake: 70,
    grip: 1.7,
    maxSpeed: 20,
    fuel: 140,
    fuelRate: 6.2,
    air: 0.7,
    torqueScale: 0.2,
    stiff: 300,
    damp: 48,
    raise: 0.72,
    angDamp: 2.8,
    headX: 0.05,
    headY: 0.7,
    body: "monster",
  },
  {
    id: "truck",
    name: "Racing Truck",
    blurb: "Long gears and a wide stance. Built for distance.",
    price: 6800,
    mass: 1.55,
    wheelbase: 2.7,
    rRear: 0.5,
    rFront: 0.5,
    engine: 92,
    brake: 68,
    grip: 1.55,
    maxSpeed: 29,
    fuel: 130,
    fuelRate: 5.6,
    air: 0.85,
    torqueScale: 0.26,
    stiff: 380,
    damp: 44,
    raise: 0.5,
    angDamp: 2.5,
    headX: 0.35,
    headY: 0.66,
    body: "truck",
  },
  {
    id: "super",
    name: "Supercar",
    blurb: "Fragile rocket. Highest top speed, lowest clearance.",
    price: 10500,
    mass: 0.84,
    wheelbase: 2.45,
    rRear: 0.34,
    rFront: 0.34,
    engine: 102,
    brake: 74,
    grip: 1.35,
    maxSpeed: 38,
    fuel: 80,
    fuelRate: 6.4,
    air: 0.95,
    torqueScale: 0.14,
    stiff: 520,
    damp: 34,
    raise: 0.28,
    angDamp: 1.8,
    headX: 0.15,
    headY: 0.36,
    body: "super",
  },
  {
    id: "heavy",
    name: "Expedition Rig",
    blurb: "Armored hauler. Massive tank, planted through anything.",
    price: 15000,
    mass: 2.8,
    wheelbase: 3.05,
    rRear: 0.62,
    rFront: 0.62,
    engine: 110,
    brake: 80,
    grip: 1.9,
    maxSpeed: 18,
    fuel: 190,
    fuelRate: 5.8,
    air: 0.4,
    torqueScale: 0.16,
    stiff: 460,
    damp: 58,
    raise: 0.64,
    angDamp: 3.6,
    headX: 0.4,
    headY: 0.82,
    body: "heavy",
  },
];

export const MAPS: MapDef[] = [
  {
    id: "hills",
    name: "Green Hills",
    region: "Meadow range",
    blurb: "Rolling grass, gentle bridges, and a long daylight.",
    seed: 101,
    seg: 9,
    amp: 2.35,
    wave: 0.52,
    gravity: 27,
    bridge: 0.08,
    gripMul: 1,
    unlockDist: 0,
    price: 0,
    skyTop: "#6eb7e0",
    skyHorizon: "#d7f0c4",
    duskTop: "#e37a3a",
    duskHorizon: "#ffd2a1",
    nightTop: "#0c1228",
    nightHorizon: "#24345a",
    mountain: "#6f97ad",
    mountainFar: "#b7d4df",
    grass: "#3e8d38",
    grassDark: "#2c6828",
    soil: "#6a4326",
    soilDeep: "#3b2414",
    prop: "meadow",
    cloud: "rgba(255,255,255,0.86)",
  },
  {
    id: "desert",
    name: "Desert",
    region: "Dune basin",
    blurb: "Hot wind, cactus, and wide sand ramps.",
    seed: 220,
    seg: 10,
    amp: 3.1,
    wave: 0.38,
    gravity: 27,
    bridge: 0.06,
    gripMul: 0.92,
    unlockDist: 350,
    price: 500,
    skyTop: "#f0a15a",
    skyHorizon: "#ffe0a8",
    duskTop: "#c4522a",
    duskHorizon: "#ffb07a",
    nightTop: "#1a1030",
    nightHorizon: "#5a2e48",
    mountain: "#c4845a",
    mountainFar: "#e8c39a",
    grass: "#e2b15a",
    grassDark: "#c4923e",
    soil: "#a86b32",
    soilDeep: "#6a3e1c",
    prop: "desert",
    cloud: "rgba(255,236,210,0.55)",
  },
  {
    id: "snow",
    name: "Snow Mountains",
    region: "High ice",
    blurb: "Steep faces and slick tires. Brake early.",
    seed: 333,
    seg: 8.6,
    amp: 3.35,
    wave: 0.62,
    gravity: 27,
    bridge: 0.1,
    gripMul: 0.78,
    unlockDist: 900,
    price: 1000,
    skyTop: "#9fd4ef",
    skyHorizon: "#eef6fb",
    duskTop: "#6f7ea8",
    duskHorizon: "#f0c2b0",
    nightTop: "#101828",
    nightHorizon: "#2a3c58",
    mountain: "#d5e4ee",
    mountainFar: "#eef5f8",
    grass: "#f4f7fb",
    grassDark: "#d5dee8",
    soil: "#8aa0b4",
    soilDeep: "#4d6274",
    prop: "snow",
    cloud: "rgba(255,255,255,0.9)",
  },
  {
    id: "forest",
    name: "Forest",
    region: "Deep timber",
    blurb: "Tight trees, dark soil, and hidden jumps.",
    seed: 414,
    seg: 8.2,
    amp: 3.2,
    wave: 0.7,
    gravity: 27,
    bridge: 0.09,
    gripMul: 1.05,
    unlockDist: 1600,
    price: 1800,
    skyTop: "#6aa0c8",
    skyHorizon: "#c9e2b2",
    duskTop: "#c46a32",
    duskHorizon: "#e7c48a",
    nightTop: "#07140f",
    nightHorizon: "#163028",
    mountain: "#3e6a48",
    mountainFar: "#7ea37a",
    grass: "#2f7a34",
    grassDark: "#1d5224",
    soil: "#4a3420",
    soilDeep: "#26180e",
    prop: "forest",
    cloud: "rgba(236,244,232,0.7)",
  },
  {
    id: "volcano",
    name: "Volcano",
    region: "Ash ridge",
    blurb: "Black rock, lava glow, and mean downhills.",
    seed: 515,
    seg: 9.2,
    amp: 2.7,
    wave: 0.58,
    gravity: 30,
    bridge: 0.12,
    gripMul: 0.96,
    unlockDist: 2800,
    price: 3200,
    skyTop: "#4a2a38",
    skyHorizon: "#e07a42",
    duskTop: "#3a1420",
    duskHorizon: "#ff6a32",
    nightTop: "#14080c",
    nightHorizon: "#6a2418",
    mountain: "#3a2428",
    mountainFar: "#6a4038",
    grass: "#4a302c",
    grassDark: "#2a1816",
    soil: "#2a1814",
    soilDeep: "#120806",
    prop: "volcano",
    cloud: "rgba(80,60,60,0.45)",
  },
  {
    id: "moon",
    name: "Moon",
    region: "Low orbit",
    blurb: "Low gravity. Flips hang forever. Land soft.",
    seed: 606,
    seg: 11,
    amp: 2.05,
    wave: 0.36,
    gravity: 11,
    bridge: 0.05,
    gripMul: 0.8,
    unlockDist: 4500,
    price: 5000,
    skyTop: "#05060e",
    skyHorizon: "#1a1e38",
    duskTop: "#05060e",
    duskHorizon: "#1a1e38",
    nightTop: "#05060e",
    nightHorizon: "#14182e",
    mountain: "#3a3e52",
    mountainFar: "#2a2e42",
    grass: "#9aa0b0",
    grassDark: "#6a7080",
    soil: "#4a4e5c",
    soilDeep: "#22242e",
    prop: "moon",
    cloud: "rgba(0,0,0,0)",
  },
];

export const SKINS: Record<string, Skin[]> = {
  jeep: [
    { name: "Olive", price: 0, body: "#6f8c3c", accent: "#e6d3a4", glass: "#163038", rim: "#d5dde2", dark: "#2c3818" },
    { name: "Sand", price: 220, body: "#c6a56c", accent: "#8d3c28", glass: "#243038", rim: "#f0e6d4", dark: "#5a4228" },
    { name: "Night", price: 480, body: "#2c3444", accent: "#e8a317", glass: "#0e1820", rim: "#aeb6be", dark: "#141820" },
    { name: "Rally", price: 860, body: "#d04532", accent: "#f4f1ea", glass: "#1a242c", rim: "#e4dccc", dark: "#4a1812" },
  ],
  bike: [
    { name: "Yellow", price: 0, body: "#f0c42e", accent: "#1e1e1e", glass: "#d8dee4", rim: "#ece7dc", dark: "#2a2414" },
    { name: "Lime", price: 220, body: "#8fbf2f", accent: "#1c1c1c", glass: "#e8eef2", rim: "#f2f2f2", dark: "#243014" },
    { name: "Blue", price: 480, body: "#2f6fbf", accent: "#f2f2f2", glass: "#d0d8e0", rim: "#d8dee6", dark: "#142033" },
    { name: "Magenta", price: 860, body: "#d63d78", accent: "#1a1a1a", glass: "#f0f0f0", rim: "#eee", dark: "#3a1424" },
  ],
  tractor: [
    { name: "Field", price: 0, body: "#3e8a32", accent: "#f2c230", glass: "#c8d4dc", rim: "#e6e0d4", dark: "#1c3414" },
    { name: "Barn", price: 250, body: "#b4372c", accent: "#f0e2c0", glass: "#d4dce2", rim: "#eee6d8", dark: "#3a1410" },
    { name: "Blue", price: 520, body: "#2c5e9a", accent: "#f0d060", glass: "#dce4ea", rim: "#e4e8ee", dark: "#14243a" },
    { name: "Classic", price: 900, body: "#d8d2c4", accent: "#c4491d", glass: "#b8c4cc", rim: "#f4f0e6", dark: "#4a463c" },
  ],
  sport: [
    { name: "Pearl", price: 0, body: "#f2f0ea", accent: "#c4491d", glass: "#1a2830", rim: "#c8ced4", dark: "#3a3834" },
    { name: "Midnight", price: 280, body: "#1c2430", accent: "#e8a317", glass: "#9ec4d4", rim: "#9aa2aa", dark: "#0c1016" },
    { name: "Guard", price: 560, body: "#c4343a", accent: "#f4f1ea", glass: "#142028", rim: "#ded6cc", dark: "#401216" },
    { name: "Emerald", price: 980, body: "#1f8a62", accent: "#f2f6f4", glass: "#102028", rim: "#d0d8d4", dark: "#0e3326" },
  ],
  monster: [
    { name: "Flame", price: 0, body: "#e07020", accent: "#1a1a1a", glass: "#c8d4dc", rim: "#f0e6c8", dark: "#3a220e" },
    { name: "Mud", price: 300, body: "#6a5438", accent: "#e8c56a", glass: "#1c282c", rim: "#d8d0c4", dark: "#2a2014" },
    { name: "Electric", price: 640, body: "#2a6adf", accent: "#f4f6f8", glass: "#102030", rim: "#dce4ee", dark: "#102040" },
    { name: "Bone", price: 1100, body: "#e8e2d4", accent: "#c4491d", glass: "#243038", rim: "#2a2a2a", dark: "#4a463c" },
  ],
  truck: [
    { name: "Sponsor", price: 0, body: "#f2f4f6", accent: "#d04532", glass: "#163040", rim: "#cfd6dc", dark: "#3a3e42" },
    { name: "Forest", price: 320, body: "#2e6a3c", accent: "#f0d060", glass: "#102018", rim: "#d8e0d4", dark: "#142818" },
    { name: "Ocean", price: 680, body: "#1e5f8a", accent: "#f4f1ea", glass: "#0c2030", rim: "#d0d8e0", dark: "#0e2838" },
    { name: "Gold", price: 1200, body: "#e0b03a", accent: "#1c1c1c", glass: "#1a242c", rim: "#f2ead4", dark: "#4a3810" },
  ],
  super: [
    { name: "Graphite", price: 0, body: "#3a3e46", accent: "#e8a317", glass: "#9ec8d8", rim: "#b8c0c8", dark: "#16181c" },
    { name: "Rosso", price: 400, body: "#c42828", accent: "#1a1a1a", glass: "#1c2c34", rim: "#e0d8d0", dark: "#3a1010" },
    { name: "Bianco", price: 800, body: "#f4f2ec", accent: "#1c1c1c", glass: "#1a2830", rim: "#c8ced4", dark: "#3c3a36" },
    { name: "Viola", price: 1400, body: "#5a2e86", accent: "#f0d060", glass: "#140820", rim: "#ddd4ea", dark: "#241038" },
  ],
  heavy: [
    { name: "Expedition", price: 0, body: "#c4a15a", accent: "#2a2e28", glass: "#1c2c30", rim: "#d8d2c6", dark: "#4a3c22" },
    { name: "Army", price: 360, body: "#5a6a3a", accent: "#1c1c14", glass: "#141c14", rim: "#c8c4b0", dark: "#242814" },
    { name: "Arctic", price: 760, body: "#e4e8ee", accent: "#2a6abf", glass: "#1a2834", rim: "#bfc6ce", dark: "#3a4048" },
    { name: "Lava", price: 1300, body: "#2a2424", accent: "#e25822", glass: "#ffb080", rim: "#a09890", dark: "#100c0c" },
  ],
};

export type Achievement = {
  id: string;
  name: string;
  desc: string;
  reward: number;
};

export const ACHIEVEMENTS: Achievement[] = [
  { id: "first", name: "First Ignition", desc: "Finish a run", reward: 40 },
  { id: "m100", name: "Trail Marker", desc: "Drive 100 m in one run", reward: 40 },
  { id: "m500", name: "Ridge Runner", desc: "Drive 500 m in one run", reward: 90 },
  { id: "m1000", name: "Kilometer Club", desc: "Drive 1,000 m in one run", reward: 180 },
  { id: "m2500", name: "Horizon Line", desc: "Drive 2,500 m in one run", reward: 360 },
  { id: "m5000", name: "Endless Crest", desc: "Drive 5,000 m in one run", reward: 700 },
  { id: "coins50", name: "Pocket Change", desc: "Pick up 50 coins in one run", reward: 60 },
  { id: "air", name: "Hang Time", desc: "Stay airborne for 2.5 seconds", reward: 80 },
  { id: "back", name: "Backflip", desc: "Land a backflip", reward: 70 },
  { id: "front", name: "Frontflip", desc: "Land a frontflip", reward: 70 },
  { id: "stunt", name: "Stunt Show", desc: "Land 3 flips in one run", reward: 140 },
  { id: "combo", name: "Combo Rider", desc: "Hit a ×3 stunt combo", reward: 120 },
  { id: "allcars", name: "Full Garage", desc: "Unlock every vehicle", reward: 500 },
  { id: "allmaps", name: "Cartographer", desc: "Unlock every region", reward: 500 },
  { id: "tuned", name: "Maxed Out", desc: "Fully upgrade any vehicle", reward: 280 },
  { id: "moon", name: "Low Gravity", desc: "Drive 400 m on the Moon", reward: 250 },
];

export const DAILY_REWARDS = [100, 150, 220, 300, 420, 600, 1000];

export function vehicleById(id: string): VehicleDef {
  return VEHICLES.find((v) => v.id === id) ?? VEHICLES[0]!;
}

export function mapById(id: string): MapDef {
  return MAPS.find((m) => m.id === id) ?? MAPS[0]!;
}

export function upgradeCost(def: VehicleDef, stat: UpgradeKey, level: number): number {
  const base = 90 + Math.floor(def.price * 0.07);
  const mult = stat === "engine" ? 1.15 : stat === "suspension" ? 1.05 : stat === "fuel" ? 0.92 : 1;
  return Math.round((base * mult * Math.pow(1.7, level)) / 10) * 10;
}

export function tune(def: VehicleDef, up: UpgradeLevels): Tuned {
  const e = up.engine;
  const t = up.tires;
  const s = up.suspension;
  const f = up.fuel;
  const mass = def.mass;
  const avgR = (def.rRear + def.rFront) / 2;
  const comAbove = avgR + def.raise * (1 + s * 0.03);
  return {
    ...def,
    mass,
    engine: def.engine * (1 + 0.16 * e),
    brake: def.brake * (1 + 0.12 * e),
    maxSpeed: def.maxSpeed * (1 + 0.075 * e),
    grip: def.grip * (1 + 0.18 * t),
    stiff: def.stiff * (1 + 0.1 * s),
    damp: def.damp * (1 + 0.12 * s),
    angDamp: def.angDamp * (1 + 0.12 * s),
    air: def.air * (1 + 0.04 * s),
    fuelCap: def.fuel * (1 + 0.22 * f),
    comAbove,
    inertia: mass * (def.wheelbase * 0.52) ** 2,
    rear: { lx: -def.wheelbase / 2, ly: def.rRear - comAbove, r: def.rRear },
    front: { lx: def.wheelbase / 2, ly: def.rFront - comAbove, r: def.rFront },
  };
}

export function hash01(seed: number, i: number, salt = 0): number {
  let n = (Math.imul(i + salt * 131 + 1, 374761393) + Math.imul(seed, 668265263)) | 0;
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  n = n ^ (n >>> 16);
  return (n >>> 0) / 4294967296;
}
