import { hash01, type MapDef, type Tuned } from "./data";

export type Surface = { y: number; nx: number; ny: number; bridge: boolean };

export type Pickup = { id: string; kind: "coin" | "fuel"; x: number; y: number; value: number };

export type SimInput = { gas: boolean; brake: boolean };

export type SimEvent =
  | { type: "coin"; x: number; y: number; amount: number }
  | { type: "fuel"; x: number; y: number; amount: number }
  | { type: "flip"; kind: "back" | "front"; combo: number; spins: number; coins: number }
  | { type: "air"; amount: number; seconds: number }
  | { type: "land"; impact: number }
  | { type: "crash"; reason: "crash" | "fall" | "fuel" }
  | { type: "milestone"; meters: number; bonus: number };

export type Run = {
  map: MapDef;
  veh: Tuned;
  x: number;
  y: number;
  vx: number;
  vy: number;
  angle: number;
  angVel: number;
  fuel: number;
  spinRear: number;
  spinFront: number;
  alive: boolean;
  endReason: "crash" | "fall" | "fuel" | null;
  distance: number;
  coins: number;
  trackCoins: number;
  flips: number;
  combo: number;
  maxCombo: number;
  lastFlipAt: number;
  airTime: number;
  airRot: number;
  bestAir: number;
  wasAir: boolean;
  groundTimer: number;
  stopTimer: number;
  time: number;
  collected: Set<string>;
  grounded: number;
  wheelWorld: [{ x: number; y: number }, { x: number; y: number }];
  head: { x: number; y: number };
  milestones: number;
  lastImpact: number;
  display: boolean;
};

const MILESTONES = [100, 250, 500, 1000, 2000, 3500, 5000, 8000];

export function hillPoint(map: MapDef, i: number): number {
  if (i <= 2) return 0;
  const n = hash01(map.seed, i, 1);
  const n2 = hash01(map.seed, i, 2);
  let h = Math.sin(i * map.wave) * map.amp * 0.62;
  h += (n - 0.5) * map.amp * 0.95;
  if (n2 > 0.84) h += map.amp * (0.28 + n * 0.35);
  if (n2 < 0.06) h -= map.amp * 0.4;
  if (hash01(map.seed, i, 8) > 0.945 && i > 8) h += map.amp * 0.85;
  if (hash01(map.seed, i - 1, 8) > 0.945 && i > 9) h -= map.amp * 0.05;
  return h;
}

export function terrainHeight(map: MapDef, x: number): number {
  const seg = map.seg;
  const i = Math.floor(x / seg);
  const t = x / seg - i;
  const s = t * t * (3 - 2 * t);
  return hillPoint(map, i) + (hillPoint(map, i + 1) - hillPoint(map, i)) * s;
}

export type Span = { x0: number; x1: number; y0: number; y1: number };

export function spanForIndex(map: MapDef, i: number): Span | null {
  if (i < 7) return null;
  const n = hash01(map.seed, i, 7);
  if (n > map.bridge) return null;
  const x0 = i * map.seg + map.seg * 0.28;
  const x1 = x0 + 5.5 + n * 70;
  return { x0, x1, y0: terrainHeight(map, x0), y1: terrainHeight(map, x1) };
}

export function spanCovering(map: MapDef, x: number): Span | null {
  const i = Math.floor(x / map.seg);
  for (let k = i - 2; k <= i + 1; k++) {
    const s = spanForIndex(map, k);
    if (s && x >= s.x0 && x <= s.x1) return s;
  }
  return null;
}

export function surfaceAt(map: MapDef, x: number): Surface {
  const span = spanCovering(map, x);
  if (span) {
    const t = (x - span.x0) / Math.max(0.001, span.x1 - span.x0);
    const y = span.y0 + (span.y1 - span.y0) * t;
    const slope = (span.y1 - span.y0) / Math.max(0.001, span.x1 - span.x0);
    const len = Math.hypot(1, slope);
    return { y, nx: -slope / len, ny: 1 / len, bridge: true };
  }
  const e = 0.18;
  const y = terrainHeight(map, x);
  const y0 = terrainHeight(map, x - e);
  const y1 = terrainHeight(map, x + e);
  const slope = (y1 - y0) / (2 * e);
  const len = Math.hypot(1, slope);
  return { y, nx: -slope / len, ny: 1 / len, bridge: false };
}

export function forEachPickup(map: MapDef, x0: number, x1: number, fn: (p: Pickup) => void) {
  const step = 14;
  const i0 = Math.floor(x0 / step) - 1;
  const i1 = Math.floor(x1 / step) + 1;
  for (let i = Math.max(2, i0); i <= i1; i++) {
    const n = hash01(map.seed, i, 3);
    const x = i * step + hash01(map.seed, i, 4) * 5;
    if (x < x0 - 2 || x > x1 + 2) continue;
    const ground = surfaceAt(map, x).y;
    if (n < 0.78) {
      const arc = hash01(map.seed, i, 5);
      const rise = arc > 0.84 ? 2.4 + arc * 2.2 : 1.25;
      fn({ id: `c${i}`, kind: "coin", x, y: ground + rise, value: 10 });
      if (arc > 0.91) {
        fn({ id: `c${i}b`, kind: "coin", x: x + 1.15, y: ground + rise + 0.7, value: 10 });
        fn({ id: `c${i}c`, kind: "coin", x: x + 2.3, y: ground + rise + 0.15, value: 10 });
      }
    }
    if (n > 0.84) {
      const xf = x + 4.2;
      const gf = surfaceAt(map, xf).y;
      fn({ id: `f${i}`, kind: "fuel", x: xf, y: gf + 1.35, value: 0.36 });
    }
  }
}

function wrapAngle(a: number): number {
  let x = a;
  while (x > Math.PI) x -= Math.PI * 2;
  while (x < -Math.PI) x += Math.PI * 2;
  return x;
}

export function createRun(map: MapDef, veh: Tuned, display = false): Run {
  const x = 7;
  const y = surfaceAt(map, x).y + veh.comAbove - 0.05;
  const run: Run = {
    map,
    veh,
    x,
    y,
    vx: 0,
    vy: 0,
    angle: 0,
    angVel: 0,
    fuel: veh.fuelCap,
    spinRear: 0,
    spinFront: 0,
    alive: true,
    endReason: null,
    distance: 0,
    coins: 0,
    trackCoins: 0,
    flips: 0,
    combo: 0,
    maxCombo: 0,
    lastFlipAt: -10,
    airTime: 0,
    airRot: 0,
    bestAir: 0,
    wasAir: false,
    groundTimer: 0,
    stopTimer: 0,
    time: 0,
    collected: new Set(),
    grounded: 0,
    wheelWorld: [
      { x, y },
      { x, y },
    ],
    head: { x, y },
    milestones: 0,
    lastImpact: 0,
    display,
  };
  placeWheels(run);
  return run;
}

function placeWheels(run: Run) {
  const c = Math.cos(run.angle);
  const s = Math.sin(run.angle);
  const mounts = [run.veh.rear, run.veh.front];
  for (let i = 0; i < 2; i++) {
    const m = mounts[i]!;
    run.wheelWorld[i]!.x = run.x + c * m.lx - s * m.ly;
    run.wheelWorld[i]!.y = run.y + s * m.lx + c * m.ly;
  }
  const hx = run.veh.headX;
  const hy = run.veh.headY;
  run.head.x = run.x + c * hx - s * hy;
  run.head.y = run.y + s * hx + c * hy;
}

function endRun(run: Run, reason: "crash" | "fall" | "fuel", events: SimEvent[]) {
  if (!run.alive || run.display) return;
  run.alive = false;
  run.endReason = reason;
  const meters = Math.floor(run.distance);
  const bonus = Math.floor(meters * 0.85) + run.flips * 5;
  run.coins += bonus;
  events.push({ type: "crash", reason });
}

function resolveAir(run: Run, events: SimEvent[]) {
  if (run.display) {
    run.airRot = 0;
    run.airTime = 0;
    return;
  }
  const spins = Math.floor(Math.abs(run.airRot) / (Math.PI * 2) + 0.08);
  if (spins >= 1) {
    const back = run.airRot > 0;
    if (run.time - run.lastFlipAt < 2.5 && run.combo > 0) run.combo += spins;
    else run.combo = spins;
    run.lastFlipAt = run.time;
    run.maxCombo = Math.max(run.maxCombo, run.combo);
    run.flips += spins;
    const coins = 25 * spins * run.combo;
    run.coins += coins;
    events.push({ type: "flip", kind: back ? "back" : "front", combo: run.combo, spins, coins });
  } else if (run.airTime > 0.55) {
    const amount = Math.floor(run.airTime * 8);
    if (amount > 0) {
      run.coins += amount;
      events.push({ type: "air", amount, seconds: run.airTime });
    }
  }
  run.bestAir = Math.max(run.bestAir, run.airTime);
  run.airRot = 0;
  run.airTime = 0;
}

export function stepRun(run: Run, input: SimInput, dt: number): SimEvent[] {
  const events: SimEvent[] = [];
  if (!run.alive) return events;
  const sub = 5;
  const h = dt / sub;
  let landed = 0;
  for (let s = 0; s < sub; s++) landed = Math.max(landed, substep(run, input, h));
  run.time += dt;
  run.distance = Math.max(run.distance, run.x - 7);
  if (landed > 7 && !run.display) {
    run.lastImpact = landed;
    events.push({ type: "land", impact: landed });
  }
  if (!run.display) collectPickups(run, events);
  if (!run.display && run.alive) checkEnd(run, events);
  if (!Number.isFinite(run.x) || !Number.isFinite(run.y) || !Number.isFinite(run.angle)) {
    endRun(run, "crash", events);
  }
  return events;
}

function substep(run: Run, input: SimInput, dt: number): number {
  const veh = run.veh;
  const map = run.map;
  const g = map.gravity;
  let gas = input.gas && run.fuel > 0 && !run.display ? 1 : 0;
  let brake = input.brake && !run.display ? 1 : 0;
  if (run.display) brake = 1;
  if (gas && brake) {
    gas = 0;
    brake = 1;
  }

  const c = Math.cos(run.angle);
  const s = Math.sin(run.angle);
  let fx = 0;
  let fy = -veh.mass * g;
  let torque = 0;
  let grounded = 0;
  let maxImpact = 0;
  const mounts = [veh.rear, veh.front];
  const spins = [run.spinRear, run.spinFront];
  const contacts: Array<{
    i: number;
    wx: number;
    wy: number;
    rx: number;
    ry: number;
    nx: number;
    ny: number;
    tx: number;
    ty: number;
    vt: number;
    spring: number;
    r: number;
  }> = [];

  for (let i = 0; i < 2; i++) {
    const m = mounts[i]!;
    const wx = run.x + c * m.lx - s * m.ly;
    const wy = run.y + s * m.lx + c * m.ly;
    run.wheelWorld[i]!.x = wx;
    run.wheelWorld[i]!.y = wy;
    const surf = surfaceAt(map, wx);
    const above = (wy - surf.y) * surf.ny;
    const pen = m.r - above;
    const rx = wx - run.x;
    const ry = wy - run.y;
    const pvx = run.vx - run.angVel * ry;
    const pvy = run.vy + run.angVel * rx;
    if (pen > 0) {
      const vn = pvx * surf.nx + pvy * surf.ny;
      if (-vn > maxImpact) maxImpact = -vn;
      let spring = pen * veh.stiff - vn * veh.damp;
      if (spring < 0) spring = 0;
      const cap = veh.mass * g * 14;
      if (spring > cap) spring = cap;
      fx += surf.nx * spring;
      fy += surf.ny * spring;
      torque += (rx * surf.ny * spring - ry * surf.nx * spring) * 0.55;
      const tx = surf.ny;
      const ty = -surf.nx;
      const vt = pvx * tx + pvy * ty;
      contacts.push({ i, wx, wy, rx, ry, nx: surf.nx, ny: surf.ny, tx, ty, vt, spring, r: m.r });
      const corr = Math.min(pen, 0.2) * 0.18;
      run.x += surf.nx * corr;
      run.y += surf.ny * corr;
      if (pen > 0.5) {
        run.y += (pen - 0.5) * 0.3;
        if (run.vy < 0) run.vy *= 0.65;
      }
    }
  }

  grounded = contacts.length;
  const share = Math.max(1, grounded);
  for (const ct of contacts) {
    let drive = 0;
    if (gas) drive = (run.vx > veh.maxSpeed ? veh.engine * 0.05 : veh.engine) / share;
    else if (brake) drive = (run.vx < -veh.maxSpeed * 0.4 ? -veh.brake * 0.12 : -veh.brake) / share;
    const rolling = (gas ? 0.45 : 1.35) * veh.mass;
    const load = ct.spring + (veh.mass * g * 0.5) / share;
    const maxF = veh.grip * map.gripMul * Math.max(load, veh.mass * g * 0.25);
    let fr = drive - ct.vt * rolling;
    if (fr > maxF) fr = maxF;
    if (fr < -maxF) fr = -maxF;
    fx += ct.tx * fr;
    fy += ct.ty * fr;
    torque += (ct.rx * ct.ty * fr - ct.ry * ct.tx * fr) * veh.torqueScale;
    spins[ct.i] = (spins[ct.i] ?? 0) - (ct.vt / ct.r) * dt;
  }

  run.spinRear = spins[0] ?? 0;
  run.spinFront = spins[1] ?? 0;
  run.grounded = grounded;

  run.vx += (fx / veh.mass) * dt;
  run.vy += (fy / veh.mass) * dt;
  run.angVel += (torque / veh.inertia) * dt;
  if (grounded === 0) {
    run.airTime += dt;
    const hold = Math.min(1, Math.max(0, run.airTime - 0.42) / 0.85);
    const target = (gas - brake) * (0.5 + hold * veh.air);
    run.angVel += (target - run.angVel) * 3.4 * dt;
  } else {
    const surf = surfaceAt(map, run.x);
    const slopeAng = Math.atan2(-surf.nx, surf.ny);
    const err = wrapAngle(slopeAng - run.angle);
    const align = grounded === 2 ? 18 : 7;
    run.angVel += err * align * dt;
    run.angVel -= run.angVel * (grounded === 2 ? 10 : 4) * dt;
    const lim = grounded === 2 ? 1.5 : 2.2;
    if (run.angVel > lim) run.angVel = lim;
    if (run.angVel < -lim) run.angVel = -lim;
  }
  if (run.angVel > 7) run.angVel = 7;
  if (run.angVel < -7) run.angVel = -7;

  const drag = 0.18 + (Math.abs(run.vx) > veh.maxSpeed ? 1.6 : 0);
  run.vx -= run.vx * drag * dt;
  if (grounded > 0 && !gas && !input.brake) {
    const sign = Math.sign(run.vx);
    const cut = Math.min(Math.abs(run.vx), 1.4 * dt);
    run.vx -= sign * cut;
  }

  run.x += run.vx * dt;
  run.y += run.vy * dt;
  run.angle += run.angVel * dt;

  if (gas && !run.display) run.fuel = Math.max(0, run.fuel - veh.fuelRate * dt);

  placeWheels(run);
  return maxImpact;
}

function collectPickups(run: Run, events: SimEvent[]) {
  forEachPickup(run.map, run.x - 3, run.x + 4, (p) => {
    if (run.collected.has(p.id)) return;
    let best = Math.hypot(p.x - run.x, p.y - run.y);
    for (const w of run.wheelWorld) best = Math.min(best, Math.hypot(p.x - w.x, p.y - w.y));
    const reach = p.kind === "coin" ? 0.85 : 1.05;
    if (best > reach) return;
    run.collected.add(p.id);
    if (p.kind === "coin") {
      run.coins += p.value;
      run.trackCoins += p.value;
      events.push({ type: "coin", x: p.x, y: p.y, amount: p.value });
    } else {
      const before = run.fuel;
      run.fuel = Math.min(run.veh.fuelCap, run.fuel + run.veh.fuelCap * p.value);
      events.push({ type: "fuel", x: p.x, y: p.y, amount: run.fuel - before });
    }
  });
}

function checkEnd(run: Run, events: SimEvent[]) {
  if (run.time < 0.45) return;
  const ang = Math.abs(wrapAngle(run.angle));
  const gy = surfaceAt(run.map, run.head.x).y;
  const inverted = ang > 2.05;
  const headPlow = run.grounded === 0 && ang > 1.7 && run.head.y < gy - 0.2;
  if ((inverted && run.head.y < gy + 0.28) || headPlow) {
    resolveIfAir(run, events);
    endRun(run, "crash", events);
    return;
  }
  if (run.y < -16) {
    resolveIfAir(run, events);
    endRun(run, "fall", events);
  }
}

function resolveIfAir(run: Run, events: SimEvent[]) {
  if (run.wasAir) resolveAir(run, events);
  run.wasAir = false;
}

export function stepRunFull(run: Run, input: SimInput, dt: number): SimEvent[] {
  const events = stepRun(run, input, dt);
  if (!run.alive || run.display) return events;

  if (run.grounded > 0) {
    run.groundTimer += dt;
    if (run.wasAir && run.groundTimer > 0.08) {
      resolveAir(run, events);
      run.wasAir = false;
    }
  } else {
    if (!run.wasAir) {
      run.airRot = 0;
      run.airTime = 0;
    }
    run.wasAir = true;
    run.groundTimer = 0;
    run.airRot += run.angVel * dt;
    run.bestAir = Math.max(run.bestAir, run.airTime);
  }

  const speed = Math.hypot(run.vx, run.vy);
  if (run.fuel <= 0 && speed < 0.75 && run.grounded > 0) run.stopTimer += dt;
  else run.stopTimer = 0;
  if (run.stopTimer > 2.1 && run.alive) {
    resolveIfAir(run, events);
    endRun(run, "fuel", events);
  }

  const meters = run.distance;
  while (run.milestones < MILESTONES.length && meters >= MILESTONES[run.milestones]!) {
    const mark = MILESTONES[run.milestones]!;
    const bonus = Math.round(20 + mark * 0.04);
    run.coins += bonus;
    run.milestones++;
    events.push({ type: "milestone", meters: mark, bonus });
  }
  return events;
}
