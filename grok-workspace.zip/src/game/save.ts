import {
  ACHIEVEMENTS,
  DAILY_REWARDS,
  EMPTY_UPGRADES,
  MAPS,
  MAX_UPGRADE,
  SKINS,
  VEHICLES,
  type UpgradeKey,
  type UpgradeLevels,
} from "./data";

export type Save = {
  v: 1;
  coins: number;
  vehicles: string[];
  maps: string[];
  upgrades: Record<string, UpgradeLevels>;
  skins: Record<string, number>;
  ownedSkins: Record<string, number[]>;
  best: Record<string, number>;
  bestOverall: number;
  achievements: string[];
  dailyDay: string;
  streak: number;
  settings: { sfx: boolean; music: boolean; shake: boolean };
  selectedVehicle: string;
  selectedMap: string;
  stats: { runs: number; flips: number; coinsEarned: number; distance: number };
};

const KEY = "torque-ridge-save-v1";

export function defaultSave(): Save {
  const upgrades: Save["upgrades"] = {};
  const skins: Save["skins"] = {};
  const ownedSkins: Save["ownedSkins"] = {};
  for (const v of VEHICLES) {
    upgrades[v.id] = { ...EMPTY_UPGRADES };
    skins[v.id] = 0;
    ownedSkins[v.id] = [0];
  }
  const best: Save["best"] = {};
  for (const m of MAPS) best[m.id] = 0;
  return {
    v: 1,
    coins: 0,
    vehicles: ["jeep"],
    maps: ["hills"],
    upgrades,
    skins,
    ownedSkins,
    best,
    bestOverall: 0,
    achievements: [],
    dailyDay: "",
    streak: 0,
    settings: { sfx: true, music: true, shake: true },
    selectedVehicle: "jeep",
    selectedMap: "hills",
    stats: { runs: 0, flips: 0, coinsEarned: 0, distance: 0 },
  };
}

function clampLevel(n: unknown): number {
  const v = typeof n === "number" && Number.isFinite(n) ? Math.floor(n) : 0;
  return Math.max(0, Math.min(MAX_UPGRADE, v));
}

export function sanitize(raw: unknown): Save {
  const base = defaultSave();
  if (!raw || typeof raw !== "object") return base;
  const p = raw as Partial<Save>;
  const next = defaultSave();
  next.coins = typeof p.coins === "number" && p.coins > 0 ? Math.floor(p.coins) : 0;
  if (Array.isArray(p.vehicles)) {
    next.vehicles = [...new Set(p.vehicles.filter((id) => VEHICLES.some((v) => v.id === id)))];
  }
  if (!next.vehicles.includes("jeep")) next.vehicles.unshift("jeep");
  if (Array.isArray(p.maps)) {
    next.maps = [...new Set(p.maps.filter((id) => MAPS.some((m) => m.id === id)))];
  }
  if (!next.maps.includes("hills")) next.maps.unshift("hills");
  if (p.upgrades && typeof p.upgrades === "object") {
    for (const v of VEHICLES) {
      const u = (p.upgrades as Record<string, Partial<UpgradeLevels>>)[v.id];
      if (!u) continue;
      next.upgrades[v.id] = {
        engine: clampLevel(u.engine),
        tires: clampLevel(u.tires),
        suspension: clampLevel(u.suspension),
        fuel: clampLevel(u.fuel),
      };
    }
  }
  if (p.skins && typeof p.skins === "object") {
    for (const v of VEHICLES) {
      const idx = (p.skins as Record<string, unknown>)[v.id];
      const max = (SKINS[v.id]?.length ?? 1) - 1;
      next.skins[v.id] = typeof idx === "number" ? Math.max(0, Math.min(max, Math.floor(idx))) : 0;
    }
  }
  if (p.ownedSkins && typeof p.ownedSkins === "object") {
    for (const v of VEHICLES) {
      const arr = (p.ownedSkins as Record<string, unknown>)[v.id];
      const max = (SKINS[v.id]?.length ?? 1) - 1;
      const owned = Array.isArray(arr)
        ? [...new Set(arr.filter((n) => typeof n === "number" && n >= 0 && n <= max).map((n) => Math.floor(n as number)))]
        : [0];
      if (!owned.includes(0)) owned.unshift(0);
      next.ownedSkins[v.id] = owned;
    }
  }
  if (p.best && typeof p.best === "object") {
    for (const m of MAPS) {
      const d = (p.best as Record<string, unknown>)[m.id];
      next.best[m.id] = typeof d === "number" && d > 0 ? d : 0;
    }
  }
  next.bestOverall = Math.max(
    typeof p.bestOverall === "number" ? p.bestOverall : 0,
    ...Object.values(next.best),
  );
  if (Array.isArray(p.achievements)) {
    next.achievements = p.achievements.filter((id) => ACHIEVEMENTS.some((a) => a.id === id));
  }
  next.dailyDay = typeof p.dailyDay === "string" ? p.dailyDay : "";
  next.streak = typeof p.streak === "number" && p.streak > 0 ? Math.min(7, Math.floor(p.streak)) : 0;
  if (p.settings && typeof p.settings === "object") {
    next.settings = {
      sfx: p.settings.sfx !== false,
      music: p.settings.music !== false,
      shake: p.settings.shake !== false,
    };
  }
  if (typeof p.selectedVehicle === "string" && next.vehicles.includes(p.selectedVehicle)) {
    next.selectedVehicle = p.selectedVehicle;
  }
  if (typeof p.selectedMap === "string" && next.maps.includes(p.selectedMap)) {
    next.selectedMap = p.selectedMap;
  }
  if (p.stats && typeof p.stats === "object") {
    next.stats = {
      runs: num(p.stats.runs),
      flips: num(p.stats.flips),
      coinsEarned: num(p.stats.coinsEarned),
      distance: num(p.stats.distance),
    };
  }
  return next;
}

function num(n: unknown): number {
  return typeof n === "number" && Number.isFinite(n) && n > 0 ? n : 0;
}

export function loadSave(): Save {
  if (typeof localStorage === "undefined") return defaultSave();
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaultSave();
    const parsed = JSON.parse(raw) as unknown;
    if (!parsed || typeof parsed !== "object" || (parsed as { v?: number }).v !== 1) return defaultSave();
    return sanitize(parsed);
  } catch {
    return defaultSave();
  }
}

export function writeSave(save: Save) {
  try {
    localStorage.setItem(KEY, JSON.stringify(save));
  } catch {
    /* ignore quota */
  }
}

export function todayKey(d = new Date()): string {
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

export function prevDay(key: string): string {
  const [y, m, day] = key.split("-").map(Number);
  const dt = new Date(y || 2026, (m || 1) - 1, day || 1);
  dt.setDate(dt.getDate() - 1);
  return todayKey(dt);
}

export function dailyStatus(save: Save): { claimable: boolean; streakNext: number; reward: number } {
  const today = todayKey();
  if (save.dailyDay === today) {
    return { claimable: false, streakNext: save.streak, reward: DAILY_REWARDS[Math.max(0, save.streak - 1)] ?? 100 };
  }
  const streakNext = save.dailyDay === prevDay(today) ? Math.min(7, save.streak + 1) : 1;
  return { claimable: true, streakNext, reward: DAILY_REWARDS[streakNext - 1] ?? 100 };
}

export function claimDaily(save: Save): { save: Save; reward: number } | null {
  const status = dailyStatus(save);
  if (!status.claimable) return null;
  const next = {
    ...save,
    coins: save.coins + status.reward,
    streak: status.streakNext,
    dailyDay: todayKey(),
    stats: { ...save.stats, coinsEarned: save.stats.coinsEarned + status.reward },
  };
  return { save: next, reward: status.reward };
}

export function upgradesFor(save: Save, id: string): UpgradeLevels {
  return save.upgrades[id] ?? { ...EMPTY_UPGRADES };
}

export function isMaxed(up: UpgradeLevels): boolean {
  return (Object.keys(up) as UpgradeKey[]).every((k) => up[k] >= MAX_UPGRADE);
}
