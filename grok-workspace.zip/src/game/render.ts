import { hash01, type MapDef, type Skin, type Tuned } from "./data";
import { forEachPickup, spanForIndex, surfaceAt, terrainHeight, type Run } from "./sim";

export type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  r: number;
  color: string;
  grav: number;
};

export type Popup = {
  x: number;
  y: number;
  text: string;
  life: number;
  max: number;
  color: string;
};

export type Frame = {
  cssW: number;
  cssH: number;
  dpr: number;
  map: MapDef;
  run: Run | null;
  camX: number;
  camY: number;
  zoom: number;
  shakeX: number;
  shakeY: number;
  time: number;
  particles: Particle[];
  popups: Popup[];
  skin: Skin;
  speedLines: number;
};

function rgb(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

function mix(a: string, b: string, t: number): string {
  const A = rgb(a);
  const B = rgb(b);
  const u = Math.max(0, Math.min(1, t));
  return `rgb(${Math.round(A[0] + (B[0] - A[0]) * u)},${Math.round(A[1] + (B[1] - A[1]) * u)},${Math.round(A[2] + (B[2] - A[2]) * u)})`;
}

function todOf(map: MapDef, x: number): number {
  if (map.id === "moon") return 0.72;
  if (map.id === "volcano") return 0.33 + Math.sin(x * 0.01) * 0.04;
  return (x * 0.00135) % 1;
}

function skyColors(map: MapDef, tod: number): { top: string; horizon: string; night: number } {
  const dayT = mix(map.skyTop, map.skyTop, 0);
  void dayT;
  if (tod < 0.18) return { top: map.skyTop, horizon: map.skyHorizon, night: 0 };
  if (tod < 0.32) {
    const t = (tod - 0.18) / 0.14;
    return { top: mix(map.skyTop, map.duskTop, t), horizon: mix(map.skyHorizon, map.duskHorizon, t), night: t * 0.3 };
  }
  if (tod < 0.42) {
    const t = (tod - 0.32) / 0.1;
    return { top: mix(map.duskTop, map.nightTop, t), horizon: mix(map.duskHorizon, map.nightHorizon, t), night: 0.3 + t * 0.7 };
  }
  if (tod < 0.72) return { top: map.nightTop, horizon: map.nightHorizon, night: 1 };
  if (tod < 0.84) {
    const t = (tod - 0.72) / 0.12;
    return { top: mix(map.nightTop, map.duskTop, t), horizon: mix(map.nightHorizon, map.duskHorizon, t), night: 1 - t * 0.6 };
  }
  const t = (tod - 0.84) / 0.16;
  return { top: mix(map.duskTop, map.skyTop, t), horizon: mix(map.duskHorizon, map.skyHorizon, t), night: 0.4 * (1 - t) };
}

export function renderFrame(ctx: CanvasRenderingContext2D, f: Frame) {
  const { cssW: w, cssH: h, dpr } = f;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const tod = todOf(f.map, f.camX);
  const sky = skyColors(f.map, tod);
  const g = ctx.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, sky.top);
  g.addColorStop(1, sky.horizon);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);

  drawCelestial(ctx, w, h, f, sky.night);
  if (sky.night > 0.45) drawStars(ctx, w, h, f, sky.night);

  ctx.save();
  ctx.translate(w * 0.5 + f.shakeX, h * 0.62 + f.shakeY);
  ctx.scale(f.zoom, -f.zoom);
  ctx.translate(-f.camX, -f.camY);

  drawMountains(ctx, f, 0.18, f.map.mountainFar, 7.2, 0.55);
  drawMountains(ctx, f, 0.38, f.map.mountain, 4.6, 1);
  drawClouds(ctx, f, sky.night);
  drawProps(ctx, f, true);
  drawTerrain(ctx, f);
  drawBridges(ctx, f);
  drawProps(ctx, f, false);
  if (f.run) drawPickups(ctx, f);
  drawParticles(ctx, f.particles, f.time);
  if (f.run) drawVehicle(ctx, f.run, f.skin);
  drawPopups(ctx, f.popups);
  ctx.restore();

  if (f.speedLines > 12) drawSpeedLines(ctx, w, h, f);
}

function drawCelestial(ctx: CanvasRenderingContext2D, w: number, h: number, f: Frame, night: number) {
  const x = w * 0.78;
  const y = h * 0.18;
  const r = Math.min(w, h) * 0.07;
  const glow = ctx.createRadialGradient(x, y, r * 0.2, x, y, r * 3.2);
  if (night > 0.6 || f.map.id === "moon") {
    glow.addColorStop(0, "rgba(255,244,210,0.35)");
    glow.addColorStop(1, "rgba(255,244,210,0)");
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(x, y, r * 3.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#f4f0e4";
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = skyDisc(f.map);
    ctx.beginPath();
    ctx.arc(x + r * 0.35, y - r * 0.15, r * 0.92, 0, Math.PI * 2);
    ctx.fill();
  } else {
    const col = night > 0.25 ? "#ffb15a" : "#ffe38a";
    glow.addColorStop(0, night > 0.25 ? "rgba(255,140,60,0.45)" : "rgba(255,220,120,0.55)");
    glow.addColorStop(1, "rgba(255,220,120,0)");
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(x, y, r * 3.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = col;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
}

function skyDisc(map: MapDef): string {
  if (map.id === "moon") return "#12162a";
  if (map.id === "volcano") return "#3a1420";
  return "#1a2748";
}

function drawStars(ctx: CanvasRenderingContext2D, w: number, h: number, f: Frame, alpha: number) {
  ctx.save();
  ctx.globalAlpha = Math.min(1, alpha);
  ctx.fillStyle = "#f4f1ea";
  for (let i = 0; i < 48; i++) {
    const sx = hash01(3, i, 1) * w;
    const sy = hash01(3, i, 2) * h * 0.55;
    const tw = 0.4 + Math.sin(f.time * 2 + i) * 0.4;
    ctx.globalAlpha = alpha * (0.35 + tw * 0.65);
    ctx.fillRect(sx, sy, 1.6, 1.6);
  }
  ctx.restore();
}

function drawMountains(
  ctx: CanvasRenderingContext2D,
  f: Frame,
  parallax: number,
  color: string,
  height: number,
  alpha: number,
) {
  const view = (f.cssW / f.zoom) * 0.5 + 8;
  const left = f.camX - view;
  const right = f.camX + view;
  ctx.beginPath();
  const base = -2.2;
  ctx.moveTo(left, base - 8);
  for (let x = left; x <= right; x += 1.4) {
    const px = x * parallax + f.map.seed * 0.01;
    const y = base + Math.sin(px * 0.18) * height * 0.45 + Math.sin(px * 0.07 + 2) * height;
    ctx.lineTo(x, y);
  }
  ctx.lineTo(right, base - 8);
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.globalAlpha = alpha;
  ctx.fill();
  ctx.globalAlpha = 1;
}

function drawClouds(ctx: CanvasRenderingContext2D, f: Frame, night: number) {
  if (f.map.id === "moon" || f.map.cloud.endsWith(",0)")) return;
  ctx.fillStyle = f.map.cloud;
  const span = 70;
  for (let i = 0; i < 7; i++) {
    const speed = 1.6 + (i % 3) * 0.4;
    const x = ((i * 18 + f.time * speed * 0.4 - f.camX * 0.15) % span + span) % span + f.camX - span * 0.5;
    const y = 6.2 + (i % 4) * 0.85 + Math.sin(f.time * 0.2 + i) * 0.15;
    const s = 1.1 + (i % 3) * 0.35;
    ctx.globalAlpha = night > 0.7 ? 0.18 : 0.9;
    blob(ctx, x, y, s);
  }
  ctx.globalAlpha = 1;
}

function blob(ctx: CanvasRenderingContext2D, x: number, y: number, s: number) {
  ctx.beginPath();
  ctx.ellipse(x, y, s * 1.4, s * 0.55, 0, 0, Math.PI * 2);
  ctx.ellipse(x - s * 0.7, y - s * 0.1, s * 0.7, s * 0.42, 0, 0, Math.PI * 2);
  ctx.ellipse(x + s * 0.6, y - s * 0.05, s * 0.8, s * 0.48, 0, 0, Math.PI * 2);
  ctx.fill();
}

function drawTerrain(ctx: CanvasRenderingContext2D, f: Frame) {
  const view = f.cssW / f.zoom + 6;
  const left = f.camX - view * 0.5 - 2;
  const right = f.camX + view * 0.5 + 2;
  const step = 0.42;
  ctx.beginPath();
  let first = true;
  for (let x = left; x <= right; x += step) {
    const y = groundVisual(f.map, x);
    if (first) {
      ctx.moveTo(x, y);
      first = false;
    } else ctx.lineTo(x, y);
  }
  ctx.lineTo(right, -30);
  ctx.lineTo(left, -30);
  ctx.closePath();
  const grad = ctx.createLinearGradient(0, 6, 0, -18);
  grad.addColorStop(0, f.map.grass);
  grad.addColorStop(0.08, f.map.grassDark);
  grad.addColorStop(0.18, f.map.soil);
  grad.addColorStop(1, f.map.soilDeep);
  ctx.fillStyle = grad;
  ctx.fill();

  ctx.beginPath();
  first = true;
  for (let x = left; x <= right; x += step) {
    const y = groundVisual(f.map, x);
    if (first) {
      ctx.moveTo(x, y);
      first = false;
    } else ctx.lineTo(x, y);
  }
  ctx.strokeStyle = f.map.id === "snow" ? "#ffffff" : f.map.grass;
  ctx.lineWidth = 0.16;
  ctx.stroke();

  if (f.map.prop !== "moon" && f.map.prop !== "volcano") {
    ctx.strokeStyle = f.map.prop === "desert" ? "#c9843a" : f.map.prop === "snow" ? "#e7eef5" : "#8fd184";
    ctx.lineWidth = 0.035;
    for (let x = Math.floor(left); x < right; x += 0.85) {
      if (spanForIndex(f.map, Math.floor(x / f.map.seg)) && insideSpan(f.map, x)) continue;
      const y = terrainHeight(f.map, x);
      const n = hash01(f.map.seed, Math.floor(x * 2), 11);
      if (n < 0.45) continue;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + 0.05, y + 0.22 + n * 0.18);
      ctx.stroke();
    }
  }

  if (f.map.prop === "volcano") {
    ctx.strokeStyle = "#ff6a2a";
    ctx.lineWidth = 0.06;
    ctx.globalAlpha = 0.85;
    for (let x = left; x < right; x += 2.2) {
      const y = groundVisual(f.map, x) - 0.05;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + 0.4, y - 0.12);
      ctx.lineTo(x + 0.9, y - 0.02);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }
}

function insideSpan(map: MapDef, x: number): boolean {
  const i = Math.floor(x / map.seg);
  for (let k = i - 2; k <= i + 1; k++) {
    const s = spanForIndex(map, k);
    if (s && x > s.x0 + 0.4 && x < s.x1 - 0.4) return true;
  }
  return false;
}

function groundVisual(map: MapDef, x: number): number {
  const base = terrainHeight(map, x);
  const i = Math.floor(x / map.seg);
  for (let k = i - 2; k <= i + 1; k++) {
    const s = spanForIndex(map, k);
    if (!s) continue;
    if (x <= s.x0 || x >= s.x1) continue;
    const t = (x - s.x0) / (s.x1 - s.x0);
    const edge = Math.sin(Math.min(1, t) * Math.PI);
    return base - edge * 3.6;
  }
  return base;
}

function drawBridges(ctx: CanvasRenderingContext2D, f: Frame) {
  const view = f.cssW / f.zoom + 4;
  const left = f.camX - view;
  const i0 = Math.floor(left / f.map.seg) - 2;
  const i1 = Math.floor((f.camX + view) / f.map.seg) + 2;
  for (let i = i0; i <= i1; i++) {
    const s = spanForIndex(f.map, i);
    if (!s) continue;
    const planks = Math.max(4, Math.floor((s.x1 - s.x0) / 0.55));
    for (let p = 0; p < planks; p++) {
      const t0 = p / planks;
      const t1 = (p + 1) / planks;
      const x0 = s.x0 + (s.x1 - s.x0) * t0;
      const x1 = s.x0 + (s.x1 - s.x0) * t1;
      const y0 = s.y0 + (s.y1 - s.y0) * t0;
      const y1 = s.y0 + (s.y1 - s.y0) * t1;
      ctx.beginPath();
      ctx.moveTo(x0, y0);
      ctx.lineTo(x1, y1);
      ctx.lineTo(x1, y1 - 0.18);
      ctx.lineTo(x0, y0 - 0.18);
      ctx.closePath();
      ctx.fillStyle = p % 2 === 0 ? "#8a5a32" : "#6e4524";
      ctx.fill();
    }
    ctx.strokeStyle = "#3a2416";
    ctx.lineWidth = 0.05;
    ctx.beginPath();
    ctx.moveTo(s.x0, s.y0);
    ctx.lineTo(s.x1, s.y1);
    ctx.stroke();
    ctx.strokeStyle = "rgba(0,0,0,0.25)";
    ctx.beginPath();
    ctx.moveTo(s.x0, s.y0 - 0.9);
    ctx.lineTo(s.x0, s.y0);
    ctx.moveTo(s.x1, s.y1 - 0.9);
    ctx.lineTo(s.x1, s.y1);
    ctx.stroke();
  }
}

function drawProps(ctx: CanvasRenderingContext2D, f: Frame, back: boolean) {
  const view = f.cssW / f.zoom + 6;
  const left = f.camX - view * 0.5;
  const right = f.camX + view * 0.5;
  const step = back ? 6.5 : 4.2;
  const i0 = Math.floor(left / step) - 1;
  const i1 = Math.floor(right / step) + 1;
  for (let i = i0; i <= i1; i++) {
    const n = hash01(f.map.seed, i, back ? 21 : 22);
    if (back ? n < 0.35 : n < 0.42) continue;
    const x = i * step + n * 1.4;
    if (insideSpan(f.map, x)) continue;
    const y = terrainHeight(f.map, x);
    const s = 0.75 + hash01(f.map.seed, i, 23) * 0.7;
    if (back) drawProp(ctx, f.map, x, y, s * 1.15, true, n);
    else drawProp(ctx, f.map, x, y, s, false, n);
  }
}

function drawProp(ctx: CanvasRenderingContext2D, map: MapDef, x: number, y: number, s: number, back: boolean, n: number) {
  ctx.save();
  ctx.translate(x, y);
  if (back) ctx.globalAlpha = 0.55;
  const kind = map.prop;
  if (kind === "desert") {
    if (n > 0.72) cactus(ctx, s);
    else rock(ctx, s, "#b88858", "#8a6238");
  } else if (kind === "snow") {
    if (n > 0.4) pine(ctx, s, "#1e4a38", true);
    else rock(ctx, s * 0.8, "#d5e0ea", "#8aa0b4");
  } else if (kind === "forest") {
    if (n > 0.33) pine(ctx, s * 1.15, "#143c22", false);
    else bush(ctx, s, "#1f6a30");
  } else if (kind === "volcano") {
    if (n > 0.62) deadTree(ctx, s);
    else rock(ctx, s, "#3a2424", "#1a1010");
  } else if (kind === "moon") {
    crater(ctx, s);
  } else if (n > 0.55) pine(ctx, s, "#1d5a30", false);
  else if (n > 0.3) bush(ctx, s, "#2f8a34");
  else rock(ctx, s * 0.7, "#7d868c", "#4e585e");
  ctx.restore();
}

function pine(ctx: CanvasRenderingContext2D, s: number, color: string, snow: boolean) {
  ctx.fillStyle = "#5a3a22";
  ctx.fillRect(-0.06 * s, 0, 0.12 * s, 0.35 * s);
  ctx.fillStyle = color;
  for (let i = 0; i < 3; i++) {
    const yy = 0.28 * s + i * 0.32 * s;
    const w = (1.05 - i * 0.22) * s;
    ctx.beginPath();
    ctx.moveTo(0, yy + 0.42 * s);
    ctx.lineTo(-w, yy);
    ctx.lineTo(w, yy);
    ctx.closePath();
    ctx.fill();
    if (snow) {
      ctx.fillStyle = "#f4f7fb";
      ctx.beginPath();
      ctx.moveTo(0, yy + 0.42 * s);
      ctx.lineTo(-w * 0.45, yy + 0.16 * s);
      ctx.lineTo(w * 0.45, yy + 0.16 * s);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = color;
    }
  }
}

function bush(ctx: CanvasRenderingContext2D, s: number, color: string) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(0, 0.22 * s, 0.28 * s, 0, Math.PI * 2);
  ctx.arc(-0.22 * s, 0.16 * s, 0.2 * s, 0, Math.PI * 2);
  ctx.arc(0.22 * s, 0.16 * s, 0.18 * s, 0, Math.PI * 2);
  ctx.fill();
}

function rock(ctx: CanvasRenderingContext2D, s: number, color: string, dark: string) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(-0.45 * s, 0);
  ctx.lineTo(-0.2 * s, 0.38 * s);
  ctx.lineTo(0.28 * s, 0.3 * s);
  ctx.lineTo(0.48 * s, 0.05 * s);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = dark;
  ctx.beginPath();
  ctx.moveTo(-0.1 * s, 0.05 * s);
  ctx.lineTo(0.05 * s, 0.22 * s);
  ctx.lineTo(0.22 * s, 0.08 * s);
  ctx.fill();
}

function cactus(ctx: CanvasRenderingContext2D, s: number) {
  ctx.fillStyle = "#2f8a45";
  round(ctx, -0.08 * s, 0, 0.16 * s, 0.85 * s, 0.08 * s);
  round(ctx, -0.36 * s, 0.28 * s, 0.34 * s, 0.1 * s, 0.05 * s);
  round(ctx, -0.36 * s, 0.28 * s, 0.1 * s, 0.28 * s, 0.05 * s);
  round(ctx, 0.08 * s, 0.42 * s, 0.3 * s, 0.1 * s, 0.05 * s);
  round(ctx, 0.28 * s, 0.42 * s, 0.1 * s, 0.24 * s, 0.05 * s);
}

function deadTree(ctx: CanvasRenderingContext2D, s: number) {
  ctx.strokeStyle = "#2a1814";
  ctx.lineWidth = 0.06 * s;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(0.05 * s, 0.7 * s);
  ctx.moveTo(0.05 * s, 0.45 * s);
  ctx.lineTo(-0.28 * s, 0.7 * s);
  ctx.moveTo(0.05 * s, 0.55 * s);
  ctx.lineTo(0.32 * s, 0.78 * s);
  ctx.stroke();
}

function crater(ctx: CanvasRenderingContext2D, s: number) {
  ctx.fillStyle = "#6a7084";
  ctx.beginPath();
  ctx.ellipse(0, 0.05 * s, 0.55 * s, 0.18 * s, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#3e4456";
  ctx.beginPath();
  ctx.ellipse(0, 0.08 * s, 0.28 * s, 0.08 * s, 0, 0, Math.PI * 2);
  ctx.fill();
}

function drawPickups(ctx: CanvasRenderingContext2D, f: Frame) {
  const run = f.run;
  if (!run) return;
  const view = f.cssW / f.zoom;
  forEachPickup(f.map, f.camX - view, f.camX + view, (p) => {
    if (run.collected.has(p.id)) return;
    if (p.kind === "coin") drawCoin(ctx, p.x, p.y, f.time);
    else drawFuelCan(ctx, p.x, p.y, f.time);
  });
}

function drawCoin(ctx: CanvasRenderingContext2D, x: number, y: number, time: number) {
  const bob = Math.sin(time * 3 + x) * 0.08;
  const spin = Math.max(0.18, Math.abs(Math.sin(time * 4 + x * 0.5)));
  ctx.save();
  ctx.translate(x, y + bob);
  ctx.scale(spin, 1);
  const g = ctx.createRadialGradient(-0.05, 0.08, 0.02, 0, 0, 0.28);
  g.addColorStop(0, "#fff1b0");
  g.addColorStop(0.45, "#f0c043");
  g.addColorStop(1, "#c48414");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(0, 0, 0.26, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#a86c10";
  ctx.lineWidth = 0.03;
  ctx.stroke();
  ctx.fillStyle = "#7a4e0c";
  ctx.scale(1 / spin, 1);
  ctx.scale(spin, -1);
  ctx.font = "bold 0.22px Outfit, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("¢", 0, 0);
  ctx.restore();
}

function drawFuelCan(ctx: CanvasRenderingContext2D, x: number, y: number, time: number) {
  const bob = Math.sin(time * 2.4 + x) * 0.08;
  ctx.save();
  ctx.translate(x, y + bob);
  ctx.fillStyle = "#d23b2f";
  round(ctx, -0.18, 0, 0.36, 0.42, 0.04);
  ctx.fillStyle = "#f4f1ea";
  ctx.fillRect(-0.18, 0.16, 0.36, 0.08);
  ctx.fillStyle = "#7a1c16";
  round(ctx, -0.08, 0.4, 0.16, 0.08, 0.02);
  ctx.strokeStyle = "#f4f1ea";
  ctx.lineWidth = 0.03;
  ctx.beginPath();
  ctx.moveTo(-0.08, 0.28);
  ctx.lineTo(0, 0.36);
  ctx.lineTo(0.08, 0.28);
  ctx.stroke();
  ctx.restore();
}

function drawParticles(ctx: CanvasRenderingContext2D, particles: Particle[], _time: number) {
  for (const p of particles) {
    const a = Math.max(0, p.life / p.max);
    ctx.globalAlpha = a;
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.r * (0.6 + a), 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
}

function drawPopups(ctx: CanvasRenderingContext2D, popups: Popup[]) {
  for (const p of popups) {
    const a = Math.max(0, Math.min(1, p.life / 0.25));
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.scale(1, -1);
    ctx.globalAlpha = Math.min(1, p.life);
    ctx.fillStyle = p.color;
    ctx.font = "700 0.42px Oswald, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(p.text, 0, 0);
    ctx.restore();
    void a;
  }
  ctx.globalAlpha = 1;
}

function drawVehicle(ctx: CanvasRenderingContext2D, run: Run, skin: Skin) {
  const v = run.veh;
  const c = Math.cos(run.angle);
  const s = Math.sin(run.angle);
  const wheels = [v.rear, v.front];
  const locals: Array<{ x: number; y: number; r: number; spin: number }> = [];
  const spins = [run.spinRear, run.spinFront];
  for (let i = 0; i < 2; i++) {
    const w = run.wheelWorld[i]!;
    const dx = w.x - run.x;
    const dy = w.y - run.y;
    locals.push({
      x: c * dx + s * dy,
      y: -s * dx + c * dy,
      r: wheels[i]!.r,
      spin: spins[i] ?? 0,
    });
  }

  ctx.save();
  ctx.translate(run.x, run.y);
  ctx.rotate(run.angle);

  ctx.strokeStyle = skin.dark;
  ctx.lineWidth = 0.05;
  ctx.lineCap = "round";
  for (let i = 0; i < 2; i++) {
    const m = wheels[i]!;
    const L = locals[i]!;
    ctx.beginPath();
    ctx.moveTo(m.lx, m.ly + 0.05);
    const steps = 5;
    for (let k = 1; k <= steps; k++) {
      const t = k / (steps + 1);
      const x = m.lx + (L.x - m.lx) * t;
      const y = m.ly + 0.05 + (L.y - m.ly) * t;
      ctx.lineTo(x + (k % 2 === 0 ? 0.07 : -0.07), y);
    }
    ctx.lineTo(L.x, L.y);
    ctx.stroke();
  }

  drawBody(ctx, v, skin);

  for (const L of locals) {
    ctx.save();
    ctx.translate(L.x, L.y);
    ctx.rotate(L.spin - run.angle);
    drawWheel(ctx, L.r, skin);
    ctx.restore();
  }
  ctx.restore();

  ctx.save();
  ctx.translate(run.x, surfaceAt(run.map, run.x).y + 0.02);
  ctx.scale(1, 0.25);
  ctx.fillStyle = "rgba(0,0,0,0.18)";
  ctx.beginPath();
  ctx.ellipse(0, 0, v.wheelbase * 0.55, v.wheelbase * 0.28, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawWheel(ctx: CanvasRenderingContext2D, r: number, skin: Skin) {
  ctx.fillStyle = "#1a1c1e";
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#2a2e32";
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.86, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#0e0e10";
  ctx.lineWidth = r * 0.08;
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.78, 0, Math.PI * 2);
  ctx.stroke();
  ctx.fillStyle = skin.rim;
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.48, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = skin.dark;
  ctx.lineWidth = r * 0.07;
  ctx.beginPath();
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI * 2;
    ctx.moveTo(Math.cos(a) * r * 0.16, Math.sin(a) * r * 0.16);
    ctx.lineTo(Math.cos(a) * r * 0.42, Math.sin(a) * r * 0.42);
  }
  ctx.stroke();
  ctx.fillStyle = skin.dark;
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.12, 0, Math.PI * 2);
  ctx.fill();
}

function drawBody(ctx: CanvasRenderingContext2D, v: Tuned, skin: Skin) {
  const kind = v.body;
  if (kind === "jeep") bodyJeep(ctx, v, skin);
  else if (kind === "monster") bodyMonster(ctx, v, skin);
  else if (kind === "sport") bodySport(ctx, v, skin);
  else if (kind === "bike") bodyBike(ctx, v, skin);
  else if (kind === "tractor") bodyTractor(ctx, v, skin);
  else if (kind === "truck") bodyTruck(ctx, v, skin);
  else if (kind === "super") bodySuper(ctx, v, skin);
  else bodyHeavy(ctx, v, skin);
}

function bodyJeep(ctx: CanvasRenderingContext2D, v: Tuned, skin: Skin) {
  const hw = v.wheelbase * 0.5;
  ctx.fillStyle = skin.body;
  round(ctx, -hw + 0.05, -0.08, v.wheelbase - 0.1, 0.42, 0.08);
  ctx.fillStyle = skin.dark;
  round(ctx, -hw - 0.02, -0.12, 0.16, 0.16, 0.03);
  round(ctx, hw - 0.16, -0.1, 0.22, 0.14, 0.03);
  ctx.fillStyle = skin.body;
  ctx.beginPath();
  ctx.moveTo(-0.25, 0.32);
  ctx.lineTo(-0.42, 0.32);
  ctx.lineTo(-0.32, 0.68);
  ctx.lineTo(0.28, 0.62);
  ctx.lineTo(0.46, 0.32);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = skin.glass;
  ctx.beginPath();
  ctx.moveTo(-0.22, 0.36);
  ctx.lineTo(-0.28, 0.6);
  ctx.lineTo(0.22, 0.56);
  ctx.lineTo(0.36, 0.36);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#f4f1ea";
  ctx.beginPath();
  ctx.arc(hw - 0.18, 0.12, 0.07, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = skin.accent;
  ctx.fillRect(-hw + 0.15, 0.08, v.wheelbase * 0.35, 0.06);
  fender(ctx, -hw, 0.02, v.rear.r);
  fender(ctx, hw, 0.02, v.front.r);
}

function bodyMonster(ctx: CanvasRenderingContext2D, v: Tuned, skin: Skin) {
  const hw = v.wheelbase * 0.46;
  ctx.fillStyle = skin.dark;
  ctx.fillRect(-hw - 0.05, 0.15, v.wheelbase * 0.92, 0.08);
  ctx.fillStyle = skin.body;
  round(ctx, -hw, 0.2, hw * 2, 0.48, 0.06);
  ctx.fillStyle = skin.glass;
  round(ctx, -0.05, 0.42, 0.55, 0.22, 0.04);
  ctx.fillStyle = skin.accent;
  ctx.fillRect(-hw, 0.32, hw * 2, 0.08);
  ctx.fillStyle = skin.dark;
  ctx.fillRect(-0.15, 0.68, 0.08, 0.22);
  ctx.fillRect(0.2, 0.68, 0.08, 0.22);
  ctx.strokeStyle = skin.accent;
  ctx.lineWidth = 0.04;
  ctx.beginPath();
  ctx.moveTo(0.24, 0.9);
  ctx.lineTo(0.24, 1.15);
  ctx.stroke();
  ctx.fillStyle = "#d23b2f";
  ctx.beginPath();
  ctx.moveTo(0.24, 1.15);
  ctx.lineTo(0.1, 1.02);
  ctx.lineTo(0.38, 1.02);
  ctx.fill();
  ctx.fillStyle = "#f4f1ea";
  ctx.beginPath();
  ctx.arc(hw * 0.85, 0.34, 0.06, 0, Math.PI * 2);
  ctx.fill();
}

function bodySport(ctx: CanvasRenderingContext2D, v: Tuned, skin: Skin) {
  const hw = v.wheelbase * 0.5;
  ctx.fillStyle = skin.body;
  ctx.beginPath();
  ctx.moveTo(-hw + 0.05, -0.02);
  ctx.lineTo(hw - 0.05, -0.02);
  ctx.lineTo(hw + 0.05, 0.16);
  ctx.lineTo(hw - 0.15, 0.28);
  ctx.lineTo(-hw + 0.25, 0.28);
  ctx.lineTo(-hw - 0.02, 0.12);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = skin.glass;
  ctx.beginPath();
  ctx.moveTo(-0.15, 0.26);
  ctx.lineTo(0.05, 0.48);
  ctx.lineTo(0.55, 0.42);
  ctx.lineTo(0.72, 0.26);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = skin.accent;
  ctx.fillRect(-0.2, 0.1, 0.7, 0.045);
  ctx.fillStyle = skin.dark;
  ctx.fillRect(hw - 0.25, 0.28, 0.08, 0.16);
  ctx.fillRect(-hw + 0.15, 0.02, 0.28, 0.08);
  ctx.fillStyle = "#f6e7a8";
  ctx.fillRect(hw - 0.12, 0.08, 0.12, 0.05);
}

function bodyBike(ctx: CanvasRenderingContext2D, v: Tuned, skin: Skin) {
  const hw = v.wheelbase * 0.5;
  ctx.strokeStyle = skin.dark;
  ctx.lineWidth = 0.06;
  ctx.beginPath();
  ctx.moveTo(-hw, -0.02);
  ctx.lineTo(-0.15, 0.28);
  ctx.lineTo(hw, -0.02);
  ctx.moveTo(-0.15, 0.28);
  ctx.lineTo(0.15, 0.42);
  ctx.lineTo(hw * 0.4, 0.05);
  ctx.stroke();
  ctx.fillStyle = skin.body;
  round(ctx, -0.28, 0.3, 0.5, 0.12, 0.06);
  ctx.strokeStyle = skin.accent;
  ctx.lineWidth = 0.05;
  ctx.beginPath();
  ctx.moveTo(0.15, 0.42);
  ctx.lineTo(0.42, 0.62);
  ctx.stroke();
  ctx.fillStyle = skin.body;
  round(ctx, -0.05, 0.48, 0.22, 0.28, 0.08);
  ctx.fillStyle = skin.dark;
  ctx.beginPath();
  ctx.arc(0.05, 0.92, 0.16, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = skin.glass;
  ctx.lineWidth = 0.04;
  ctx.beginPath();
  ctx.arc(0.05, 0.92, 0.1, 0.4, Math.PI);
  ctx.stroke();
  ctx.strokeStyle = skin.dark;
  ctx.lineWidth = 0.045;
  ctx.beginPath();
  ctx.moveTo(-0.02, 0.72);
  ctx.lineTo(0.28, 0.58);
  ctx.moveTo(0.02, 0.7);
  ctx.lineTo(-0.15, 0.4);
  ctx.stroke();
}

function bodyTractor(ctx: CanvasRenderingContext2D, v: Tuned, skin: Skin) {
  const rear = v.rear.lx;
  const front = v.front.lx;
  ctx.fillStyle = skin.body;
  round(ctx, rear + 0.15, 0.05, front - rear - 0.1, 0.55, 0.06);
  ctx.fillStyle = skin.dark;
  round(ctx, -0.05, 0.45, 0.42, 0.28, 0.05);
  ctx.fillStyle = skin.glass;
  ctx.fillRect(0.02, 0.52, 0.22, 0.14);
  ctx.fillStyle = skin.accent;
  ctx.fillRect(rear + 0.25, 0.2, 0.7, 0.1);
  ctx.strokeStyle = skin.dark;
  ctx.lineWidth = 0.06;
  ctx.beginPath();
  ctx.moveTo(front - 0.15, 0.55);
  ctx.lineTo(front - 0.15, 0.95);
  ctx.stroke();
  ctx.fillStyle = "#555";
  ctx.beginPath();
  ctx.arc(front - 0.15, 0.98, 0.06, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = skin.dark;
  ctx.lineWidth = 0.04;
  ctx.beginPath();
  ctx.arc(rear + 0.15, 0.15, v.rRear * 0.95, 0.15, Math.PI - 0.15);
  ctx.stroke();
}

function bodyTruck(ctx: CanvasRenderingContext2D, v: Tuned, skin: Skin) {
  const hw = v.wheelbase * 0.5;
  ctx.fillStyle = skin.body;
  round(ctx, -hw, -0.05, hw * 1.15, 0.4, 0.05);
  round(ctx, -0.15, 0.28, hw * 0.85, 0.48, 0.06);
  ctx.fillStyle = skin.glass;
  ctx.beginPath();
  ctx.moveTo(0.05, 0.36);
  ctx.lineTo(0.15, 0.68);
  ctx.lineTo(hw * 0.55, 0.64);
  ctx.lineTo(hw * 0.72, 0.36);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = skin.accent;
  ctx.fillRect(-hw, 0.12, hw * 0.9, 0.08);
  ctx.fillStyle = skin.dark;
  ctx.beginPath();
  ctx.arc(hw * 0.35, 0.78, 0.1, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = skin.accent;
  ctx.font = "700 0.16px Oswald, sans-serif";
  ctx.save();
  ctx.scale(1, -1);
  ctx.fillText("7", hw * 0.28, -0.84);
  ctx.restore();
  ctx.fillStyle = "#f4f1ea";
  ctx.fillRect(hw * 0.62, 0.42, 0.1, 0.06);
}

function bodySuper(ctx: CanvasRenderingContext2D, v: Tuned, skin: Skin) {
  const hw = v.wheelbase * 0.5;
  ctx.fillStyle = skin.body;
  ctx.beginPath();
  ctx.moveTo(-hw, 0);
  ctx.lineTo(hw, 0);
  ctx.quadraticCurveTo(hw + 0.15, 0.12, hw - 0.2, 0.22);
  ctx.lineTo(0.35, 0.34);
  ctx.lineTo(-0.05, 0.4);
  ctx.lineTo(-hw + 0.15, 0.2);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = skin.glass;
  ctx.beginPath();
  ctx.moveTo(-0.05, 0.22);
  ctx.lineTo(0.02, 0.36);
  ctx.lineTo(0.32, 0.32);
  ctx.lineTo(0.4, 0.2);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = skin.accent;
  ctx.fillRect(-hw * 0.2, 0.08, hw * 0.7, 0.035);
  ctx.fillStyle = "#ffd27a";
  ctx.beginPath();
  ctx.moveTo(hw - 0.05, 0.06);
  ctx.lineTo(hw + 0.08, 0.1);
  ctx.lineTo(hw - 0.02, 0.14);
  ctx.fill();
  ctx.fillStyle = skin.dark;
  ctx.fillRect(-hw + 0.2, 0.18, 0.18, 0.08);
}

function bodyHeavy(ctx: CanvasRenderingContext2D, v: Tuned, skin: Skin) {
  const hw = v.wheelbase * 0.5;
  ctx.fillStyle = skin.body;
  round(ctx, -hw, -0.02, hw * 2, 0.5, 0.05);
  round(ctx, hw * 0.15, 0.42, hw * 0.7, 0.42, 0.05);
  ctx.fillStyle = skin.glass;
  ctx.fillRect(hw * 0.35, 0.5, hw * 0.38, 0.22);
  ctx.fillStyle = skin.dark;
  ctx.fillRect(-hw - 0.08, 0.05, 0.2, 0.28);
  ctx.fillRect(-hw * 0.2, 0.84, hw * 1.1, 0.08);
  ctx.fillRect(-hw * 0.05, 0.72, 0.16, 0.14);
  ctx.fillRect(hw * 0.35, 0.72, 0.16, 0.14);
  ctx.strokeStyle = skin.dark;
  ctx.lineWidth = 0.05;
  ctx.beginPath();
  ctx.moveTo(hw * 0.7, 0.55);
  ctx.lineTo(hw * 0.95, 0.95);
  ctx.stroke();
  ctx.fillStyle = skin.accent;
  ctx.fillRect(-hw + 0.15, 0.18, hw * 1.3, 0.08);
  ctx.fillStyle = "#f4f1ea";
  ctx.beginPath();
  ctx.arc(hw * 0.72, 0.55, 0.06, 0, Math.PI * 2);
  ctx.fill();
}

function fender(ctx: CanvasRenderingContext2D, x: number, y: number, r: number) {
  ctx.strokeStyle = "rgba(0,0,0,0.25)";
  ctx.lineWidth = 0.05;
  ctx.beginPath();
  ctx.arc(x, y, r * 0.95, 0.15, Math.PI - 0.15);
  ctx.stroke();
}

function round(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rr = Math.min(r, w * 0.5, h * 0.5);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
  ctx.fill();
}

function drawSpeedLines(ctx: CanvasRenderingContext2D, w: number, h: number, f: Frame) {
  ctx.save();
  ctx.globalAlpha = Math.min(0.35, (f.speedLines - 12) / 40);
  ctx.strokeStyle = "#f4efe4";
  ctx.lineWidth = 2;
  const t = f.time * 18;
  for (let i = 0; i < 8; i++) {
    const y = ((i * 97 + t * 40) % h);
    ctx.beginPath();
    ctx.moveTo(w, y);
    ctx.lineTo(w - 40 - (i % 3) * 20, y - 2);
    ctx.stroke();
  }
  ctx.restore();
}
