import { MAPS, VEHICLES, tune, EMPTY_UPGRADES } from "../src/game/data.ts";
import { createRun, stepRunFull } from "../src/game/sim.ts";

const map = MAPS[0]!;
const jeep = tune(VEHICLES[0]!, EMPTY_UPGRADES);
const run = createRun(map, jeep);
const dt = 1 / 60;
let crashed = false;
for (let i = 0; i < 60 * 8; i++) {
  const ev = stepRunFull(run, { gas: true, brake: false }, dt);
  if (ev.some((e) => e.type === "crash")) crashed = true;
  if (i % 60 === 0) {
    console.log(
      `t=${(i / 60).toFixed(0)} x=${run.x.toFixed(1)} y=${run.y.toFixed(2)} vx=${run.vx.toFixed(2)} ang=${run.angle.toFixed(2)} fuel=${run.fuel.toFixed(0)} g=${run.grounded} alive=${run.alive}`,
    );
  }
}
console.log("--- brake ---");
const vxBefore = run.vx;
for (let i = 0; i < 90; i++) stepRunFull(run, { gas: false, brake: true }, dt);
console.log(`after brake vx ${vxBefore.toFixed(2)} -> ${run.vx.toFixed(2)} x=${run.x.toFixed(1)} alive=${run.alive}`);

const rev = createRun(map, jeep);
for (let i = 0; i < 120; i++) stepRunFull(rev, { gas: false, brake: true }, dt);
console.log(`reverse vx=${rev.vx.toFixed(2)} x=${rev.x.toFixed(1)} ang=${rev.angle.toFixed(2)} alive=${rev.alive}`);

const air = createRun(map, tune(VEHICLES[1]!, EMPTY_UPGRADES));
air.y += 8;
air.vy = 2;
const a0 = air.angle;
for (let i = 0; i < 40; i++) stepRunFull(air, { gas: true, brake: false }, dt);
console.log(`bike air angle ${a0.toFixed(2)} -> ${air.angle.toFixed(2)} y=${air.y.toFixed(2)} grounded=${air.grounded}`);

for (const m of MAPS) {
  for (const def of VEHICLES) {
    const r = createRun(m, tune(def, EMPTY_UPGRADES));
    let dead = "";
    for (let i = 0; i < 60 * 12; i++) {
      const ev = stepRunFull(r, { gas: true, brake: false }, dt);
      const crash = ev.find((e) => e.type === "crash");
      if (crash && crash.type === "crash") {
        dead = `${crash.reason} @${r.distance.toFixed(0)}m ang=${r.angle.toFixed(2)}`;
        break;
      }
    }
    console.log(`${m.id.padEnd(8)} ${def.id.padEnd(8)} dist=${r.distance.toFixed(0).padStart(4)} fuel=${r.fuel.toFixed(0).padStart(3)} ${dead || "ok"}`);
  }
}
if (!(run.x > 40) || !run.alive) {
  console.error("FAIL drive");
  process.exit(1);
}
console.log("drive ok");
