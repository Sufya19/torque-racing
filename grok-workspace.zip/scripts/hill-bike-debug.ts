import { MAPS, VEHICLES, tune, EMPTY_UPGRADES } from "../src/game/data.ts";
import { createRun, stepRunFull } from "../src/game/sim.ts";

const map = MAPS[0]!;
const bike = tune(VEHICLES.find((v) => v.id === "bike")!, EMPTY_UPGRADES);
const run = createRun(map, bike);
const dt = 1 / 60;
for (let i = 0; i < 60 * 4; i++) {
  const ev = stepRunFull(run, { gas: true, brake: false }, dt);
  if (i % 10 === 0) {
    console.log(
      `t=${(i / 60).toFixed(2)} x=${run.x.toFixed(1)} ang=${run.angle.toFixed(2)} av=${run.angVel.toFixed(2)} g=${run.grounded} air=${run.airTime.toFixed(2)}`,
    );
  }
  if (ev.some((e) => e.type === "crash")) {
    console.log("CRASH", run.endReason, "ang", run.angle);
    break;
  }
}
